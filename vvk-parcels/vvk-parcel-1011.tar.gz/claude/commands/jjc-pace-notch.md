---
argument-hint: <file1> [file2...]
description: JJ-aware git commit with Claude-generated message
---

Create a git commit with Job Jockey context prefix. Requires explicit file list.

Arguments: $ARGUMENTS (one or more file paths to commit)

## Prerequisites

- Must have pace context from `/jjc-heat-mount`, OR
- Provide heat-only context with Firemark

## Execution

**Step 1: Prompt user for one-line commit intent**

Ask the user: "One-line summary of what you're committing:"

If the user provides a message, use `--intent "<message>"` in the command.
If the user declines or provides empty input, omit `--intent` (haiku generates message).

**Step 2: Execute commit**

**Pace-affiliated commit (default):**
Use PACE_CORONET from current session context:
```bash
./tt/vvw-r.RunVVX.sh jjx_notch <PACE_CORONET> [--intent "<message>"] <file1> [file2...]
```

**Heat-only commit (no pace affiliation):**
Use FIREMARK for commits that affect the heat but not a specific pace:
```bash
./tt/vvw-r.RunVVX.sh jjx_notch <FIREMARK> [--intent "<message>"] <file1> [file2...]
```

The Rust command handles: lock, staging specified files only, guard, message generation (or using intent), commit, release.

## File list requirement

- At least one file must be specified
- All files must exist
- Only specified files are staged and committed
- Warning printed for uncommitted changes outside the file list

## Large Commits

The default size guard rejects commits over 50KB. For legitimate large commits:

```bash
./tt/vvw-r.RunVVX.sh jjx_notch <IDENTITY> --size-limit 200000 <file1> [file2...]
```

**Requirement**: The pace spec must justify why the large commit is necessary.
