---
argument-hint: <firemark>
description: Retire a completed heat (redirects to specific commands)
---

This command has been split into two variants:

- `/jjc-heat-retire-dryrun` — Preview what would be retired (no changes)
- `/jjc-heat-retire-FINAL` — Actually retire with confirmation

Run `/jjc-heat-retire-dryrun $ARGUMENTS` to preview, then `/jjc-heat-retire-FINAL $ARGUMENTS` to execute.
